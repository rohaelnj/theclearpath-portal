// app/plans/page.tsx
"use client";

import { PLANS } from '@/lib/brand';
import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { getAuthClient } from '@/lib/firebase';

/**
 * Subscription plan selection page.
 * Shows available plans and redirects to Stripe checkout to start a subscription.
 */
export default function PlansPage(): React.ReactElement {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState<null | string>(null);

  useEffect(() => {
    const auth = getAuthClient();
    if (!auth.currentUser) {
      router.replace('/login');
    }
  }, [router]);

  async function handleSelect(planKey: keyof typeof PLANS) {
    setError('');
    setLoading(planKey);
    try {
      const auth = getAuthClient();
      const user = auth.currentUser;
      if (!user || !user.email) {
        setError('Please log in to continue.');
        setLoading(null);
        return;
      }
      // Determine if a credit should be applied from the URL (e.g., ?credit=199)
      const creditParam = searchParams?.get('credit');
      let creditMinor: number | undefined;
      if (creditParam) {
        const creditAED = Number(creditParam);
        if (Number.isFinite(creditAED) && creditAED > 0) {
          creditMinor = Math.round(creditAED * 100);
        }
      }
      // Call API to create subscription checkout session
      const res = await fetch('/api/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'subscription',
          plan: planKey,
          customerEmail: user.email,
          // Pass the creditMinor so the API can attach a coupon if configured
          creditMinor,
          successUrl: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/plans`,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data?.url) {
        setError(data?.error || 'Unable to start checkout.');
        setLoading(null);
        return;
      }
      // Redirect to Stripe checkout
      window.location.href = data.url as string;
    } catch (err: any) {
      setError(err?.message || 'Failed to create checkout session');
      setLoading(null);
    }
  }

  return (
    <main className="min-h-screen bg-[#DFD6C7] p-6">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-semibold text-[#1F4142]">Choose Your Plan</h1>
        {/* If a credit query param is present, inform the user that it will be applied at checkout */}
        {(() => {
          const credit = searchParams?.get('credit');
          const creditNum = credit ? Number(credit) : NaN;
          return Number.isFinite(creditNum) && creditNum > 0 ? (
            <p className="mb-4 rounded-md bg-[#FEF7EC] p-3 text-sm text-[#1F4142] shadow ring-1 ring-[#F9E0C7]">
              Your AED&nbsp;{creditNum.toLocaleString()} credit will be automatically applied on your first monthly invoice.
            </p>
          ) : null;
        })()}
        <div className="grid gap-6 md:grid-cols-3">
          {Object.values(PLANS).map((plan) => (
            <div
              key={plan.key}
              className="flex flex-col rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-200"
            >
              <h2 className="mb-2 text-xl font-semibold text-[#1F4142]">{plan.name}</h2>
              <p className="mb-4 text-2xl font-bold text-[#1F4142]">AED {plan.monthlyAED.toLocaleString()}</p>
              <ul className="mb-4 list-disc space-y-1 pl-5 text-sm text-gray-700">
                {plan.perks.map((perk) => (
                  <li key={perk}>{perk}</li>
                ))}
              </ul>
              <button
                onClick={() => handleSelect(plan.key)}
                disabled={loading === plan.key}
                className="mt-auto rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90"
              >
                {loading === plan.key ? 'Loading…' : 'Select Plan'}
              </button>
            </div>
          ))}
        </div>
        {error && <p className="mt-4 text-red-600">{error}</p>}

        {/* Micro-CTA for users unsure about plans */}
        <div className="mt-8 max-w-xl text-[#1F4142] text-sm">
          <p>
            Unsure which plan is right for you? Book a{' '}
            <strong>40‑min Intro Session for AED 199</strong> — not therapy, just a clinical
            intake & plan recommendation. Your AED 199 fee is fully credited if you start a
            subscription within 48 hours.
          </p>
          <p className="mt-2">
            <a
              href="/portal"
              className="inline-block mt-1 underline text-[#1F4142] hover:text-[#183536]"
            >
              Book Intro Session →
            </a>
          </p>
        </div>
      </div>
    </main>
  );
}