// app/intake/page.tsx
"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAuthClient } from '@/lib/firebase';

/**
 * Simple intake form for new clients.
 * Captures a few basic questions and submits them to the API.
 */
export default function IntakePage(): React.ReactElement {
  const router = useRouter();
  const [q1, setQ1] = useState('');
  const [q2, setQ2] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'submitted' | 'error'>('idle');

  useEffect(() => {
    const auth = getAuthClient();
    const u = auth.currentUser;
    if (!u) {
      router.replace('/login');
    }
  }, [router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setStatus('submitting');
    const auth = getAuthClient();
    const u = auth.currentUser;
    if (!u) {
      setError('Not authenticated.');
      setStatus('error');
      return;
    }
    const uid = u.uid;
    const answers: Record<string, string> = {
      reason: q1.trim(),
      goals: q2.trim(),
    };
    try {
      const res = await fetch('/api/intake/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid, answers, notes }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Submission failed');
        setStatus('error');
        return;
      }
      setStatus('submitted');
      // After intake, redirect to plans
      router.replace('/plans');
    } catch (err: any) {
      setError(err?.message || 'Submission failed');
      setStatus('error');
    }
  }

  return (
    <main className="min-h-screen bg-[#DFD6C7] p-6">
      <div className="mx-auto max-w-md rounded-xl bg-white p-6 shadow-md">
        <h1 className="mb-4 text-2xl font-semibold text-[#1F4142]">Intake Survey</h1>
        {status === 'submitted' ? (
          <p className="text-[#1F4142]">Thank you! Your responses have been recorded.</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-[#1F4142]">
                Why are you seeking therapy?
              </label>
              <textarea
                value={q1}
                onChange={(e) => setQ1(e.target.value)}
                className="w-full rounded-md border border-gray-300 p-2"
                rows={3}
                required
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-[#1F4142]">
                What goals would you like to achieve?
              </label>
              <textarea
                value={q2}
                onChange={(e) => setQ2(e.target.value)}
                className="w-full rounded-md border border-gray-300 p-2"
                rows={3}
                required
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-[#1F4142]">Additional notes (optional)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full rounded-md border border-gray-300 p-2"
                rows={2}
              />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button
              type="submit"
              disabled={status === 'submitting'}
              className="w-full rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90"
            >
              {status === 'submitting' ? 'Submitting…' : 'Submit'}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}