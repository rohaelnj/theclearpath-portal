import ManageBookingCard from './components/ManageBookingCard';
import dynamic from 'next/dynamic';

// Dynamically import BookSession to avoid SSR issues with Firebase auth
const BookSession = dynamic(() => import('./components/BookSession'), { ssr: false });
const IntroSessionCard = dynamic(() => import('./components/IntroSessionCard'), { ssr: false });
const SupportTicketForm = dynamic(() => import('./components/SupportTicketForm'), { ssr: false });

export const dynamic = 'force-dynamic';

export default function PortalPage() {
  return (
    <main className="min-h-screen bg-[#DFD6C7] p-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-200">
          <h1 className="text-2xl font-semibold text-[#1F4142]">Your Dashboard</h1>
          <p className="mt-2 text-sm text-gray-700">
            Welcome to your portal. From here you can complete your intake survey, choose a subscription
            plan and manage your sessions.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href="/intake"
              className="rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90"
            >
              Complete Intake
            </a>
            <a
              href="/plans"
              className="rounded-md bg-[#376265] px-4 py-2 text-white hover:opacity-90"
            >
              Choose a Plan
            </a>
          </div>
        </section>
        <section>
          <ManageBookingCard />
        </section>
        <section>
          {/* Only show the booking widget if there is no confirmed booking (handled inside component) */}
          <BookSession />
        </section>
        <section>
          {/* First intro session offer for new users */}
          <IntroSessionCard />
        </section>
      <section>
        {/* Support ticket form */}
        <SupportTicketForm />
      </section>
      </div>
    </main>
  );
}
