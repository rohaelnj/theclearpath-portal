// app/(protected)/portal/components/BookSession.tsx
"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAuthClient } from '@/lib/firebase';
import { SESSION } from '@/lib/brand';

interface Slot {
  slotId: string;
  tid: string;
  startIso: string | null;
  endIso: string | null;
}

/**
 * Component to display available slots for the logged‑in user and initiate a booking + payment flow.
 */
export default function BookSession({ priceAED, durationMin, intro }: { priceAED?: number; durationMin?: number; intro?: boolean } = {}): React.ReactElement {
  const router = useRouter();
  const [loadingSlots, setLoadingSlots] = useState(true);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [error, setError] = useState('');
  const [selectedSlot, setSelectedSlot] = useState<string>('');
  const [bookingLoading, setBookingLoading] = useState(false);

  useEffect(() => {
    async function fetchSlots() {
      try {
        const auth = getAuthClient();
        const uid = auth.currentUser?.uid;
        if (!uid) return;
        const res = await fetch(`/api/slots/my?uid=${uid}`);
        const data = await res.json();
        if (!res.ok) {
          setError(data?.error || 'Failed to load slots');
          setLoadingSlots(false);
          return;
        }
        setSlots(data.slots || []);
      } catch (e: any) {
        setError(e?.message || 'Failed to load slots');
      } finally {
        setLoadingSlots(false);
      }
    }
    fetchSlots().catch(() => {});
  }, []);

  async function handleBook() {
    setError('');
    setBookingLoading(true);
    try {
      const auth = getAuthClient();
      const user = auth.currentUser;
      if (!user || !user.uid) {
        setError('Not logged in');
        setBookingLoading(false);
        return;
      }
      const uid = user.uid;
      const selected = slots.find((s) => s.slotId === selectedSlot);
      if (!selected || !selected.startIso) {
        setError('Please select a slot');
        setBookingLoading(false);
        return;
      }
      const bookingId = `book-${Date.now()}`;
      const price = priceAED ?? SESSION.singlePriceAED;
      // Hold the slot and create a pending booking
      const holdRes = await fetch('/api/bookings/hold', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId,
          uid,
          startIso: selected.startIso,
          priceAED: price,
          durationMin,
        }),
      });
      const holdJson = await holdRes.json();
      if (!holdRes.ok || !holdJson?.ok) {
        setError(holdJson?.error || 'Failed to hold slot');
        setBookingLoading(false);
        return;
      }
      const slotId = holdJson.booking?.slotId || selected.slotId;
      // Create checkout session for payment
      const checkoutRes = await fetch('/api/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'payment',
          bookingId,
          slotId,
          amountMinor: Math.round(price * 100),
          successUrl: `${window.location.origin}/success?${intro ? 'intro=true&' : ''}session_id={CHECKOUT_SESSION_ID}&booking=${bookingId}`,
          cancelUrl: `${window.location.origin}/booking/${bookingId}?payment=cancelled`,
        }),
      });
      const checkoutJson = await checkoutRes.json();
      if (!checkoutRes.ok || !checkoutJson?.url) {
        setError(checkoutJson?.error || 'Failed to create checkout');
        setBookingLoading(false);
        return;
      }
      // Redirect to Stripe Checkout
      window.location.href = checkoutJson.url as string;
    } catch (e: any) {
      setError(e?.message || 'Booking failed');
      setBookingLoading(false);
    }
  }

  if (loadingSlots) {
    return <p>Loading available slots…</p>;
  }
  if (error) {
    return <p className="text-red-600">{error}</p>;
  }
  if (!slots.length) {
    return <p>No available slots at this time. Please check back later.</p>;
  }
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-gray-200">
      <h2 className="mb-2 text-xl font-semibold text-[#1F4142]">
        {priceAED && priceAED !== SESSION.singlePriceAED ? 'Book Intro Session' : 'Book a Session'}
      </h2>
      <label htmlFor="slot" className="mb-1 block text-sm text-gray-700">
        Select a time:
      </label>
      <select
        id="slot"
        value={selectedSlot}
        onChange={(e) => setSelectedSlot(e.target.value)}
        className="mb-4 w-full rounded-md border border-gray-300 p-2"
      >
        <option value="" disabled>
          -- choose a slot --
        </option>
        {slots.map((s) => (
          <option key={s.slotId} value={s.slotId}>
            {s.startIso
              ? new Date(s.startIso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })
              : s.slotId}
          </option>
        ))}
      </select>
      <button
        onClick={handleBook}
        disabled={!selectedSlot || bookingLoading}
        className="rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90 disabled:opacity-50"
      >
        {bookingLoading ? 'Processing…' : 'Continue to Payment'}
      </button>
    </div>
  );
}