// app/(protected)/portal/components/IntroSessionCard.tsx
"use client";

import { useEffect, useState } from 'react';
import { getAuthClient } from '@/lib/firebase';
import dynamic from 'next/dynamic';

// Dynamically import BookSession to avoid SSR issues
const BookSession = dynamic(() => import('./BookSession'), { ssr: false });

/**
 * Card offering a special first 40‑minute introductory session.
 * Only new users with no existing bookings are eligible.
 */
export default function IntroSessionCard(): React.ReactElement | null {
  const [eligible, setEligible] = useState<boolean | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    async function checkEligibility() {
      try {
        const auth = getAuthClient();
        const uid = auth.currentUser?.uid;
        if (!uid) return;
        const res = await fetch(`/api/bookings/eligibility?uid=${uid}`);
        const data = await res.json();
        if (!res.ok) {
          setError(data?.error || 'Eligibility check failed');
          setEligible(false);
          return;
        }
        setEligible(data.eligible);
      } catch (e: any) {
        setError(e?.message || 'Eligibility check failed');
        setEligible(false);
      }
    }
    checkEligibility().catch(() => {});
  }, []);

  if (eligible === null) {
    return <p>Checking eligibility…</p>;
  }
  if (!eligible) {
    return null;
  }
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-gray-200">
      <h2 className="mb-2 text-xl font-semibold text-[#1F4142]">First Session — 40 min intro</h2>
      <p className="mb-2 text-sm text-gray-700">
        AED 199 (VAT‑inclusive). One‑time 40‑minute consult for new users. No texting, no emergency calls.
      </p>
      <BookSession priceAED={199} durationMin={40} intro={true} />
    </div>
  );
}