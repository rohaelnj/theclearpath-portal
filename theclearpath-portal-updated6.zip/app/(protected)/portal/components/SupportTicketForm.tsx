// app/(protected)/portal/components/SupportTicketForm.tsx
"use client";

import { useState } from 'react';

/**
 * A simple form to submit a support ticket. Users can describe issues or ask questions.
 */
export default function SupportTicketForm(): React.ReactElement {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('submitting');
    setError('');
    try {
      const res = await fetch('/api/support/ticket', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, message }),
      });
      const data = await res.json();
      if (!res.ok || !data?.ok) {
        setError(data?.error || 'Failed to submit ticket');
        setStatus('error');
        return;
      }
      setStatus('success');
      setSubject('');
      setMessage('');
    } catch (err: any) {
      setError(err?.message || 'Failed to submit ticket');
      setStatus('error');
    }
  }

  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-gray-200">
      <h2 className="mb-2 text-xl font-semibold text-[#1F4142]">Need Help?</h2>
      {status === 'success' ? (
        <p className="text-green-700">Your ticket has been submitted. We will get back to you soon.</p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
              className="mt-1 w-full rounded-md border border-gray-300 p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              className="mt-1 w-full rounded-md border border-gray-300 p-2"
              rows={3}
            />
          </div>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={status === 'submitting'}
            className="rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90 disabled:opacity-50"
          >
            {status === 'submitting' ? 'Submitting…' : 'Submit Ticket'}
          </button>
        </form>
      )}
    </div>
  );
}