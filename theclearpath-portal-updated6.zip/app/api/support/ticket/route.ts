import { NextRequest, NextResponse } from 'next/server';
import { FieldValue, db } from '@/lib/firestore';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface Body {
  subject?: string;
  message?: string;
}

/**
 * Create a general support ticket. Requires user to be authenticated via middleware (req.auth).
 */
export async function POST(req: NextRequest) {
  try {
    const auth = (req as any).auth || null;
    const { subject, message } = (await req.json()) as Body;
    if (!subject || !message) {
      return NextResponse.json({ error: 'Missing subject or message' }, { status: 400 });
    }
    const doc = {
      kind: 'support_ticket' as const,
      subject,
      message,
      createdAt: FieldValue.serverTimestamp(),
      requesterUid: auth?.uid || null,
      status: 'new' as const,
    };
    const ref = await db.collection('support_tickets').add(doc);
    return NextResponse.json({ ok: true, ticketId: ref.id });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to create ticket' }, { status: 400 });
  }
}