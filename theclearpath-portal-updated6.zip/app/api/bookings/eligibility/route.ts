import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/firestore';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Determine if a user is eligible for the introductory session.
 * Eligible if the user has no existing bookings (any status).
 */
export async function GET(req: NextRequest) {
  try {
    const uid = req.nextUrl.searchParams.get('uid')?.trim();
    if (!uid) {
      return NextResponse.json({ error: 'missing_uid' }, { status: 400 });
    }
    const db = getDb();
    const snap = await db.collection('bookings').where('uid', '==', uid).limit(1).get();
    const eligible = snap.empty;
    return NextResponse.json({ ok: true, eligible });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'eligibility_failed' }, { status: 400 });
  }
}