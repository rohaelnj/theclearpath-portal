import ManageBookingCard from './components/ManageBookingCard';

export const dynamic = 'force-dynamic';

export default function PortalPage() {
  return <ManageBookingCard />;
}
