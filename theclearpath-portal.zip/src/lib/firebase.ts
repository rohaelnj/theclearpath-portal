export { app, auth } from "../firebaseClient";
