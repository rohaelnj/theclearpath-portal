#!/usr/bin/env node
/*
 * Batch-create intro slots in Firestore.
 *
 * This script uses Firebase Admin SDK to write 40-minute (or custom length) "intro"
 * slots to your `slots` collection. It accepts one or more --start ISO timestamps
 * (e.g. 2025-10-20T11:00:00+04:00) and an optional --repeat-weeks flag to repeat
 * the same weekday/time for N subsequent weeks. Slots are created for a given
 * therapist ID (--tid). A dry-run is performed by default; pass --commit to
 * persist the writes. Existing slots are skipped automatically.
 *
 * Usage examples:
 *   node scripts/create_intro_slots.mjs --tid t2 --start 2025-10-20T11:00:00+04:00
 *   node scripts/create_intro_slots.mjs --tid t1 --start 2025-10-21T09:00:00+04:00 \
 *     --repeat-weeks 4 --duration 30 --commit
 *
 * Required environment variables (same as other scripts):
 *   FIREBASE_ADMIN_PROJECT_ID
 *   FIREBASE_ADMIN_CLIENT_EMAIL
 *   FIREBASE_ADMIN_PRIVATE_KEY_B64
 */

import admin from 'firebase-admin';

// Parse command-line arguments
const args = process.argv.slice(2);
function getArg(name, defaultValue) {
  const idx = args.indexOf(`--${name}`);
  if (idx >= 0 && idx + 1 < args.length) return args[idx + 1];
  return defaultValue;
}
function hasFlag(name) {
  return args.includes(`--${name}`);
}

const tid = getArg('tid');
const starts = []; // collect multiple --start values
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--start' && i + 1 < args.length) {
    starts.push(args[i + 1]);
  }
}
const repeatWeeks = parseInt(getArg('repeat-weeks', '0'), 10) || 0;
const durationMin = parseInt(getArg('duration', '40'), 10) || 40;
const commit = hasFlag('commit');

if (!tid || !starts.length) {
  console.error('Usage: --tid <therapistId> --start <ISO> [--start <ISO> ...] [--repeat-weeks N] [--duration minutes] [--commit]');
  process.exit(1);
}

const { FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL, FIREBASE_ADMIN_PRIVATE_KEY_B64 } = process.env;
if (!FIREBASE_ADMIN_PROJECT_ID || !FIREBASE_ADMIN_CLIENT_EMAIL || !FIREBASE_ADMIN_PRIVATE_KEY_B64) {
  console.error('Missing Firebase admin credentials. Ensure FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL and FIREBASE_ADMIN_PRIVATE_KEY_B64 are set.');
  process.exit(1);
}

const privateKey = Buffer.from(FIREBASE_ADMIN_PRIVATE_KEY_B64, 'base64').toString('utf8');
admin.initializeApp({
  credential: admin.credential.cert({
    projectId: FIREBASE_ADMIN_PROJECT_ID,
    clientEmail: FIREBASE_ADMIN_CLIENT_EMAIL,
    privateKey,
  }),
  projectId: FIREBASE_ADMIN_PROJECT_ID,
});

const db = admin.firestore();

function slotIdFrom(tid, iso) {
  return `${tid}_${iso.replace(/[:.]/g, '-')}`;
}

function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

async function createSlots() {
  const todo = [];
  for (const iso of starts) {
    const baseDate = new Date(iso);
    if (Number.isNaN(baseDate.getTime())) {
      console.error(`Invalid start ISO: ${iso}`);
      continue;
    }
    for (let i = 0; i <= repeatWeeks; i++) {
      const startDate = new Date(baseDate.getTime() + i * 7 * 24 * 60 * 60 * 1000);
      const endDate = addMinutes(startDate, durationMin);
      const startIso = startDate.toISOString();
      const endIso = endDate.toISOString();
      const slotId = slotIdFrom(tid, startIso);
      todo.push({ slotId, startIso, endIso });
    }
  }
  for (const { slotId, startIso, endIso } of todo) {
    const slotRef = db.collection('slots').doc(slotId);
    const snap = await slotRef.get();
    if (snap.exists) {
      console.log(`SKIP: slot ${slotId} already exists`);
      continue;
    }
    console.log(`${commit ? 'CREATE' : 'DRY'}: ${slotId} (${startIso} → ${endIso})`);
    if (commit) {
      await slotRef.set({
        therapistId: tid,
        start: startIso,
        end: endIso,
        status: 'open',
        sessionType: 'intro',
        isIntro: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  }
  console.log('Done.');
}

createSlots().catch((err) => {
  console.error(err);
  process.exit(1);
});