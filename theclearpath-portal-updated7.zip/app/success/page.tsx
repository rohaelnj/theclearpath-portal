export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import Stripe from 'stripe';

type Search = Record<string, string | string[] | undefined>;

type Props = {
  searchParams: Promise<Search>;
};

export default async function SuccessPage({ searchParams }: Props) {
  const sp = await searchParams;
  const booking = (sp.booking as string) ?? 'unknown';
  const sessionId = (sp.session_id as string) ?? 'unknown';
  const intro = typeof sp.intro === 'string';

  let status = 'unknown';
  if (
    sessionId !== 'unknown' &&
    sessionId.startsWith('cs_') &&
    process.env.STRIPE_SECRET_KEY
  ) {
    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2025-08-27.basil',
      });
      const session = await stripe.checkout.sessions.retrieve(sessionId);
      status = session.payment_status ?? 'unknown';
    } catch {
      status = 'unknown';
    }
  }

  return (
    <div className="min-h-screen bg-[#e8e0d5] text-[#1f3a37] flex items-center justify-center p-6">
      <div className="w-full max-w-xl rounded-2xl bg-white shadow-lg ring-1 ring-black/5 p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 overflow-hidden rounded-full ring-1 ring-[#1f3a37]/10 bg-[#e8e0d5] flex items-center justify-center">
            <img src="/logo.png" alt="The Clear Path" width={40} height={40} />
          </div>
          <h1 className="text-xl font-semibold">Payment status</h1>
        </div>

        <p className="text-sm text-[#1f3a37]/70">
          Thank you for choosing <span className="font-medium">The Clear Path</span>.
        </p>

        <div className="mt-6 grid gap-3 text-sm">
          <div className="flex justify-between border-b pb-2">
            <span className="text-[#1f3a37]/60">Booking</span>
            <span className="font-medium">{booking}</span>
          </div>
          <div className="flex justify-between border-b pb-2">
            <span className="text-[#1f3a37]/60">Stripe session</span>
            <span className="font-mono text-xs truncate max-w-[60%]">{sessionId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#1f3a37]/60">Status</span>
            <span className="font-semibold capitalize">
              {status === 'paid' ? 'Paid' : status}
            </span>
          </div>
        </div>

        <div className="mt-8 flex items-center gap-3">
          <a
            href="/portal"
            className="inline-flex items-center justify-center rounded-xl bg-[#1f3a37] px-4 py-2 text-white hover:opacity-95 transition"
          >
            Back to portal
          </a>
          <a
            href={`/booking/${booking}`}
            className="text-[#1f3a37] underline underline-offset-4 hover:opacity-80"
          >
            Manage booking
          </a>
        </div>

        {intro && (
          <div className="mt-6 rounded-lg bg-[#fef7ec] p-4 border border-[#f9e0c7]">
            <h2 className="mb-2 text-lg font-semibold text-[#1f3a37]">Apply your AED 199 credit</h2>
            <p className="mb-2 text-sm text-[#1f3a37]/80">
              Thanks for completing your 40‑minute intro session! You can apply your AED 199 credit toward any monthly
              subscription plan. Select a plan below to get started.
            </p>
            <a
              href="/plans?credit=199"
              className="inline-block rounded-md bg-[#1f3a37] px-4 py-2 text-white hover:opacity-90"
            >
              Choose a plan
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
