// app/plans/page.tsx
"use client";

import { PLANS } from '@/lib/brand';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAuthClient } from '@/lib/firebase';

/**
 * Subscription plan selection page.
 * Shows available plans and redirects to Stripe checkout to start a subscription.
 */
export default function PlansPage(): React.ReactElement {
  const router = useRouter();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState<null | string>(null);

  useEffect(() => {
    const auth = getAuthClient();
    if (!auth.currentUser) {
      router.replace('/login');
    }
  }, [router]);

  async function handleSelect(planKey: keyof typeof PLANS) {
    setError('');
    setLoading(planKey);
    try {
      const auth = getAuthClient();
      const user = auth.currentUser;
      if (!user || !user.email) {
        setError('Please log in to continue.');
        setLoading(null);
        return;
      }
      // Call API to create subscription checkout session
      const res = await fetch('/api/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'subscription',
          plan: planKey,
          customerEmail: user.email,
          successUrl: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/plans`,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data?.url) {
        setError(data?.error || 'Unable to start checkout.');
        setLoading(null);
        return;
      }
      // Redirect to Stripe checkout
      window.location.href = data.url as string;
    } catch (err: any) {
      setError(err?.message || 'Failed to create checkout session');
      setLoading(null);
    }
  }

  return (
    <main className="min-h-screen bg-[#DFD6C7] p-6">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-semibold text-[#1F4142]">Choose Your Plan</h1>
        <div className="grid gap-6 md:grid-cols-3">
          {Object.values(PLANS).map((plan) => (
            <div
              key={plan.key}
              className="flex flex-col rounded-2xl bg-white p-6 shadow-sm ring-1 ring-gray-200"
            >
              <h2 className="mb-2 text-xl font-semibold text-[#1F4142]">{plan.name}</h2>
              <p className="mb-4 text-2xl font-bold text-[#1F4142]">AED {plan.monthlyAED.toLocaleString()}</p>
              <ul className="mb-4 list-disc space-y-1 pl-5 text-sm text-gray-700">
                {plan.perks.map((perk) => (
                  <li key={perk}>{perk}</li>
                ))}
              </ul>
              <button
                onClick={() => handleSelect(plan.key)}
                disabled={loading === plan.key}
                className="mt-auto rounded-md bg-[#1F4142] px-4 py-2 text-white hover:opacity-90"
              >
                {loading === plan.key ? 'Loading…' : 'Select Plan'}
              </button>
            </div>
          ))}
        </div>
        {error && <p className="mt-4 text-red-600">{error}</p>}
      </div>
    </main>
  );
}