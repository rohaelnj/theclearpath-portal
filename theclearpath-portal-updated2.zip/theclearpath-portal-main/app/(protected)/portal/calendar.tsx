// app/portal/calendar.tsx
export default function BookingCalendar() {
  return (
    <div style={{
      background: '#fff',
      padding: '2rem',
      borderRadius: 12,
      boxShadow: '0 2px 8px rgba(0,0,0,0.07)'
    }}>
      <h3>Booking calendar coming soon…</h3>
      {/* Later, add your actual calendar UI here */}
    </div>
  );
}
